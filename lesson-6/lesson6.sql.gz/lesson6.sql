-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 07 2021 г., 19:41
-- Версия сервера: 5.6.43
-- Версия PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lesson6`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(11) NOT NULL,
  `id_session` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id_cart`, `id_session`, `id_good`, `count`) VALUES
(12, '4f1olq66mau2mqafclfnmri3nd9o28na', 9, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` double NOT NULL,
  `status` int(11) NOT NULL,
  `small_img` varchar(50) NOT NULL,
  `big_img` varchar(50) NOT NULL,
  `short_desc` text NOT NULL,
  `long_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `status`, `small_img`, `big_img`, `short_desc`, `long_desc`) VALUES
(1, 'Суккуленты', 349, 0, 'small/succulent.jpg', 'big/succulent.jpg', 'Комнатное растение в горшке, 6 см', 'Растет в засушливых регионах по всему миру.\r\nПростое в уходе растение.\r\nИдеальное растение для офиса.\r\nЭто растение чувствительно к холодной воде и недостаточному поливу, что может выражаться в опадании листьев.'),
(2, 'Хамедорея Элеганс', 129, 0, 'small/hamedoreya-elegans.jpg', 'big/hamedoreya-elegans.jpg', 'Растение в горшке, Хамедорея изящная, 9 см', 'Для использования в помещении.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.Умеренный полив. '),
(3, 'Каллуна', 299, 0, 'small/calluna.jpg', 'big/calluna.jpg', 'Растение в горшке, разные цвета, 13 см', 'Украсьте дом растениями в подходящих для вашего интерьера кашпо.\r\nОбласть естественного распространения: Европа. Для использования вне помещения.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.'),
(4, 'Фикус Бенджамина', 499, 0, 'small/ficus.jpg', 'big/ficus.jpg', 'Растение в горшке, Фикус Бенджамина \"Наташа\", 12 см', 'Область естественного распространения: Юго-Восточная Азия, Австралия и Африка.\r\nБыстрый рост.\r\nЭто растение чувствительно к сквознякам.\r\nРастение чувствительно к перемещениям.\r\nРастение чувствительно к недостатку света и перемещениям, что может выражаться в опадании листьев.'),
(5, 'Дипсис Желтоватый', 2999, 0, 'small/dypsis.jpg', 'big/dypsis.jpg', 'Растение в горшке, Хризалидокарпус желтоватый, 24 см', 'Область естественного распространения: Мадагаскар.\r\nИдеальное растение для офиса.\r\nЭто растение чувствительно к сквознякам. Для использования в помещении.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.'),
(6, 'Алоэ Вера', 349, 0, 'small/aloe-vera.jpg', 'big/aloe-vera.jpg', 'Растение в горшке, Алоэ, 12 см', 'Область естественного распространения: Южная Африка.\r\nПростое в уходе растение.\r\nМедленный рост. Предпочитает теплую среду.\r\nДля использования в помещении.\r\nРазмещать в хорошо освещенном солнечном месте.'),
(7, 'Фаленопсис', 389, 0, 'small/1606397215.jpg', 'big/1606397215.jpg', 'Растение в горшке, 12 см', 'Область естественного распространения: Азия.\r\nЭто растение чувствительно к сквознякам.\r\nЭто растение чувствительно к перепадам температуры.\r\nЭто растение чувствительно к избыточному поливу. Излишняя влага может ограничить доступ кислорода к корням, что вызовет повреждения растения.'),
(9, 'цветок', 389, 0, 'small/1606397034.jpg', 'big/1606397163.jpg', 'цветок', 'лодвполдвплодполдвы апдыжлвподыпоыждпо');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `user_login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_pass` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `user_login`, `user_name`, `user_pass`, `user_phone`, `user_role`) VALUES
(7, 'ivan', 'ivan', '2c42e5cf1cdbafea04ed267018ef1511', '99999', 0),
(8, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', '999', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
